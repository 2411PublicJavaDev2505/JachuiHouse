package com.house.jachui.member.service;

import com.house.jachui.member.vo.MemberVO;

public interface MemberService {

	int memberSignupJachui(MemberVO member);

}
