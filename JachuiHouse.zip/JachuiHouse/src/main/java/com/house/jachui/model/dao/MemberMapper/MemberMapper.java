package com.house.jachui.model.dao.MemberMapper;

public interface MemberMapper {

}
