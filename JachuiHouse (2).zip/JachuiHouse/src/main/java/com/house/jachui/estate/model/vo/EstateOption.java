package com.house.jachui.estate.model.vo;

public class EstateOption {

	private int optionNo;
	private int estateNo;
	private String optionName;
}
