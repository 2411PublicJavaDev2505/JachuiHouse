package com.house.jachui.chat.vo;

public class ChatVO {
	
}
