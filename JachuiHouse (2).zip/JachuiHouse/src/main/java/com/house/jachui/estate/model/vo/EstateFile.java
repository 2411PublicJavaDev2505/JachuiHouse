package com.house.jachui.estate.model.vo;

public class EstateFile {

	private int estateFileNo;
	private String estateFileName;
	private String estateFilePath;
	private String estateFileRename;
	private int estateNo;
}
