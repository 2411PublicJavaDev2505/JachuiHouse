package com.house.jachui.estate.model.mapper;

public interface EstateMapper {

}
