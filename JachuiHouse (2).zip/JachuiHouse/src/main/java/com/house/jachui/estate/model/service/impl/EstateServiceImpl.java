package com.house.jachui.estate.model.service.impl;

public class EstateServiceImpl {

}
