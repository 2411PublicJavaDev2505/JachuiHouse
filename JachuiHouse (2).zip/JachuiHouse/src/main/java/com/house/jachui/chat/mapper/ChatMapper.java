package com.house.jachui.chat.mapper;

public class ChatMapper {

}
