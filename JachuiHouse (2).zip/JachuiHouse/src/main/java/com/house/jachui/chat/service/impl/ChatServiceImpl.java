package com.house.jachui.chat.service.impl;

public class ChatServiceImpl {

}
