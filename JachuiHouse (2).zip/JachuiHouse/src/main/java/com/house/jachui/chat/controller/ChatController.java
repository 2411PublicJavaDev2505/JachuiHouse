package com.house.jachui.chat.controller;

public class ChatController {

}
