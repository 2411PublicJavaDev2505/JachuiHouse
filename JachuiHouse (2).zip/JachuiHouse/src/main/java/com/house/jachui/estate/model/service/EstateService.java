package com.house.jachui.estate.model.service;

public interface EstateService {

}
