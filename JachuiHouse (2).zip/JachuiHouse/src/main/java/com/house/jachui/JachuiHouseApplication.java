package com.house.jachui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JachuiHouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(JachuiHouseApplication.class, args);
	}

}

