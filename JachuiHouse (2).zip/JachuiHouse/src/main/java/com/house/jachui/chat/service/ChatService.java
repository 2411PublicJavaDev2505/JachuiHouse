package com.house.jachui.chat.service;

public interface ChatService {

}
